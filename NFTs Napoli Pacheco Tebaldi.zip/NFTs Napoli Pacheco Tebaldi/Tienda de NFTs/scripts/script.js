var saldo = 100000

function search() {
    let input = document.getElementById('searchbar').value;
    input=input.toLowerCase();
    let x = document.getElementsByClassName('cajadeproducto');
      
    for (i = 0; i < x.length; i++) { 
        if (!x[i].innerHTML.toLowerCase().includes(input)) {
            x[i].style.display="none";
            document.getElementById('nada').innerHTML = "Esos son todos nuestros resultados @_@!";
        }
        else {
            x[i].style.display="flex";   
            document.getElementById('nada').innerHTML = "";
              
        }
    }
}

let products = [];
let total = 0;

function add(product, price){
    console.log(product, price); 
    products.push(product);
    total = total + price;
    document.getElementById("checkout").innerHTML = `Pagar $${total}`;
}   

function pay(){
    if (saldo >= total){
        window.alert(products.join(", \n"));
        saldo = saldo - total
        total = 0;
        products = [];
        document.getElementById("checkout").innerHTML = `Pagar $${total}`;
    }
    else if (saldo < total){
        total = 0;
        products = [];
        document.getElementById("checkout").innerHTML = `Pagar $${total}`;
        alert("no te alcanza pobre de mierda");
    }
}

function darkMode() {
      
    const fecha = new Date(); 
    const hora = fecha.getHours();
   
    if(hora >= 0 && hora < 19){
        document.body.style.backgroundImage = "URL('img/fondo.jpg')";
        document.getElementById("all").style.backgroundColor = "rgb(231, 227, 179)";
        document.getElementById("nada").style.backgroundColor = "rgb(231, 227, 179)";
    }


        else if(hora >= 19 && hora < 24){
            document.body.style.backgroundImage = "URL('img/fondooscuro.jpg')";
            
            document.getElementById("all").style.backgroundColor = "#62427a";

            // Cambiar color a cajadeproducto 
            var parent = document.getElementById("page-content");
            var child = parent.querySelectorAll(".cajadeproducto");
            for(let i=0; i < 15; i++) {
                child[i].style.backgroundColor = "#62427a";
            }
            // textito de los resultados adaptado al modo evil
            document.getElementById("nada").style.color = "black";
            document.getElementById("nada").style.backgroundColor = "#62427a";
            document.getElementById("footer").style.backgroundColor = "#62427a";
    }

}

function verSaldo(){
    alert(`Tu saldo es de ${saldo}`)
}

function addSaldo(){
    saldo = saldo + 10000
}

window.addEventListener("load",function() { darkMode() });


