let usuarios = { 
    usuario : 123,
    juan : 345,
    profe : 789
}


const $btnSignIn= document.querySelector('.sign-in-btn'),
      $btnSignUp = document.querySelector('.sign-up-btn'),  
      $signUp = document.querySelector('.sign-up'),
      $signIn  = document.querySelector('.sign-in');

document.addEventListener('click', e => {
    if (e.target === $btnSignIn || e.target === $btnSignUp) {
        $signIn.classList.toggle('active');
        $signUp.classList.toggle('active')
    }
});

function login(){
    var getUser = document.getElementById("user").value;
    var getPasswd =  document.getElementById("password").value;
    if (getUser in usuarios){
        if (usuarios[getUser] == getPasswd){
            alert(`Bienvenido ${document.getElementById("user").value}`);
            window.location.href = "index.html";}
        if (!(usuarios[getUser] == getPasswd)){
            alert("Usuario o contraseña incorrecta");
        }
    }
    else {
        alert("Usuario no registrado");}
    }

function createUser(){
    var getNewUser = document.getElementById("newUser").value;
    var getNewPasswd = document.getElementById("newPassword").value;
    if (!(getNewUser in usuarios)){
        if (getNewUser == "" || getNewPasswd == ""){
            alert("Usuario o contraseña en blanco");}
        else {
            usuarios[getNewUser] = getNewPasswd;
            alert("Registrado correctamente");}
        }
    else if (getNewUser in usuarios){
        alert("Usuario ya existente");
    }
}
    
document.body.style.backgroundImage = "URL('img/login.jpg')";

 